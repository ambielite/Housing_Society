import {
    Users,
    Building2,
    Wallet,
    ShieldCheck
} from "lucide-react";

const Dashboard = () => {

    const cards = [
        {
            title: "Total Residents",
            value: "0",
            icon: Users
        },
        {
            title: "Total Societies",
            value: "0",
            icon: Building2
        },
        {
            title: "Outstanding Dues",
            value: "₹0",
            icon: Wallet
        },
        {
            title: "Pending Approvals",
            value: "0",
            icon: ShieldCheck
        }
    ];

    return (
        <div className="dashboard-page">

            <div className="page-header">

                <div>
                    <h1>Dashboard</h1>

                    <p>
                        Overview of your housing society
                        operations.
                    </p>
                </div>

            </div>

            <div className="dashboard-cards">

                {cards.map((card) => {

                    const Icon = card.icon;

                    return (
                        <div
                            className="stat-card"
                            key={card.title}
                        >

                            <div className="stat-icon">
                                <Icon size={22} />
                            </div>

                            <div>
                                <span>
                                    {card.title}
                                </span>

                                <h2>
                                    {card.value}
                                </h2>
                            </div>

                        </div>
                    );
                })}

            </div>

            <div className="dashboard-grid">

                <div className="dashboard-panel">

                    <h3>Recent Activity</h3>

                    <div className="empty-state">
                        No recent activity available.
                    </div>

                </div>

                <div className="dashboard-panel">

                    <h3>Pending Tasks</h3>

                    <div className="empty-state">
                        No pending tasks.
                    </div>

                </div>

            </div>

        </div>
    );
};

export default Dashboard;