import { useState } from "react";
import SocietyContext from "./society.context";

const readStoredSociety = () => {
    try {
        const storedSociety = localStorage.getItem("selectedSociety");
        return storedSociety ? JSON.parse(storedSociety) : null;
    } catch {
        localStorage.removeItem("selectedSociety");
        localStorage.removeItem("selectedSocietyId");
        return null;
    }
};

export const SocietyProvider = ({ children }) => {
    const [selectedSociety, setSelectedSociety] = useState(readStoredSociety);

    const selectSociety = (society) => {
        setSelectedSociety(society);
        localStorage.setItem("selectedSociety", JSON.stringify(society));
        localStorage.setItem("selectedSocietyId", String(society.id));
    };

    const clearSociety = () => {
        setSelectedSociety(null);
        localStorage.removeItem("selectedSociety");
        localStorage.removeItem("selectedSocietyId");
    };

    return (
        <SocietyContext.Provider value={{ selectedSociety, selectSociety, clearSociety }}>
            {children}
        </SocietyContext.Provider>
    );
};
