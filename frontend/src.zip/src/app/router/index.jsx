import {
    BrowserRouter,
    Navigate,
    Route,
    Routes
} from "react-router-dom";

import AppShell from "../../components/layout/AppShell";
import SocietyListPage from "../../features/societies/pages/SocietyListPage";
import DashboardPage from "../../features/dashboard/pages/DashboardPage";
import TowerListPage from "../../features/towers/pages/TowerListPage";
import FloorListPage from "../../features/floors/pages/FloorListPage";
import UnitListPage from "../../features/units/pages/UnitListPage";

const AppRoutes = () => {
    return (
        <BrowserRouter>

            <Routes>

                {/* <Route
                    path="/login"
                    element={
                        <div className="placeholder-page">
                            Login will be built next.
                        </div>
                    }
                /> */}

                

                    <Route element={<AppShell />}>

                        <Route
                            path="/dashboard"
                            element={<DashboardPage />}
                        />

                        <Route
                            index
                            element={
                                <Navigate
                                    to="/dashboard"
                                    replace
                                />
                            }
                        />

                        <Route
                            path="*"
                            element={
                                <div className="placeholder-page">
                                    This module will be implemented soon.
                                </div>
                            }
                        />
                        <Route
                            path="/societies"
                            element={<SocietyListPage />}
                        />

                        <Route path="/towers" element={<TowerListPage />} />
                        <Route path="/floors" element={<FloorListPage />} />
                        <Route path="/units" element={<UnitListPage />} />

                    </Route>

              

            </Routes>

        </BrowserRouter>
    );
};

export default AppRoutes;
