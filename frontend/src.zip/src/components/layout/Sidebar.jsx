import {
    LayoutDashboard,
    Building2,
    Layers3,
    Users,
    UserRound,
    Home,
    Wallet,
    Shield,
    Package,
    Headphones,
    Bell,
    MessageSquare,
    BarChart3,
    Settings,
    LogOut,
    ChevronDown
} from "lucide-react";

import {
    NavLink,
    useLocation
} from "react-router-dom";

import {
    useEffect,
    useState
} from "react";

import { useAuth } from "../../app/providers/useAuth";

const Sidebar = ({
    isOpen = false,
    onNavigate
}) => {

    const { logout } = useAuth();
    const location = useLocation();

    const societyPaths = [
        "/societies",
        "/towers",
        "/floors",
        "/units"
    ];

    const isSocietyRoute =
        societyPaths.includes(location.pathname);

    const [societyMenuOpen, setSocietyMenuOpen] =
        useState(isSocietyRoute);

    /*
     * Automatically control Society dropdown
     * based on current route.
     */
    useEffect(() => {

        if (isSocietyRoute) {
            setSocietyMenuOpen(true);
        } else {
            setSocietyMenuOpen(false);
        }

    }, [
        location.pathname,
        isSocietyRoute
    ]);

    const menuItems = [
        {
            label: "Dashboard",
            path: "/dashboard",
            icon: LayoutDashboard
        },

        {
            label: "Societies",
            path: "/societies",
            icon: Building2,

            children: [
                {
                    label: "Towers",
                    path: "/towers",
                    icon: Building2
                },
                {
                    label: "Floors",
                    path: "/floors",
                    icon: Layers3
                },
                {
                    label: "Units",
                    path: "/units",
                    icon: Home
                }
            ]
        },

        {
            label: "Residents",
            path: "/residents",
            icon: Users
        },

        {
            label: "Non-Members",
            path: "/non-members",
            icon: UserRound
        },

        {
            label: "Property",
            path: "/property",
            icon: Home
        },

        {
            label: "Finance",
            path: "/finance",
            icon: Wallet
        },

        {
            label: "Security",
            path: "/security",
            icon: Shield
        },

        {
            label: "Assets",
            path: "/assets",
            icon: Package
        },

        {
            label: "Helpdesk",
            path: "/helpdesk",
            icon: Headphones
        },

        {
            label: "Notifications",
            path: "/notifications",
            icon: Bell
        },

        {
            label: "Community",
            path: "/community",
            icon: MessageSquare
        },

        {
            label: "Reports",
            path: "/reports",
            icon: BarChart3
        },

        {
            label: "Settings",
            path: "/settings",
            icon: Settings
        }
    ];

    return (
        <aside
            className={`sidebar${isOpen ? " open" : ""}`}
        >

            {/* LOGO */}

            <div className="sidebar-logo">

                <div className="logo-mark">
                    HS
                </div>

                <div>
                    <h2>Housing Society</h2>
                    <h6>Management Platform</h6>
                </div>

            </div>


            {/* SIDEBAR NAVIGATION */}

            <nav className="sidebar-nav">

                {menuItems.map((item) => {

                    const Icon = item.icon;


                    /*
                     * SOCIETY MENU
                     */

                    if (item.children) {

                        return (
                            <div
                                className="sidebar-nav-group"
                                key={item.path}
                            >

                                <div className="sidebar-nav-group-heading">

                                    {/* Society Dashboard */}

                                    <NavLink
                                        to={item.path}
                                        className={({ isActive }) =>
                                            `nav-item${
                                                isActive
                                                    ? " active"
                                                    : ""
                                            }`
                                        }
                                        onClick={() => {

                                            // Open dropdown
                                            setSocietyMenuOpen(true);

                                            // Close mobile sidebar
                                            onNavigate?.();

                                        }}
                                    >

                                        <Icon size={19} />

                                        <span>
                                            {item.label}
                                        </span>

                                    </NavLink>


                                    {/* Dropdown Button */}

                                    <button
                                        type="button"
                                        className={`sidebar-submenu-toggle${
                                            societyMenuOpen
                                                ? " open"
                                                : ""
                                        }`}
                                        aria-label={
                                            societyMenuOpen
                                                ? "Collapse society menu"
                                                : "Expand society menu"
                                        }
                                        aria-expanded={
                                            societyMenuOpen
                                        }
                                        onClick={() => {

                                            setSocietyMenuOpen(
                                                (open) => !open
                                            );

                                        }}
                                    >

                                        <ChevronDown size={16} />

                                    </button>

                                </div>


                                {/* SOCIETY SUBMENU */}

                                {societyMenuOpen && (

                                    <div className="sidebar-subnav">

                                        {item.children.map(
                                            (child) => {

                                                const ChildIcon =
                                                    child.icon;

                                                return (
                                                    <NavLink
                                                        key={
                                                            child.path
                                                        }
                                                        to={
                                                            child.path
                                                        }
                                                        className={({
                                                            isActive
                                                        }) =>
                                                            `sidebar-subnav-item${
                                                                isActive
                                                                    ? " active"
                                                                    : ""
                                                            }`
                                                        }
                                                        onClick={() => {

                                                            // Keep Society
                                                            // dropdown open
                                                            setSocietyMenuOpen(
                                                                true
                                                            );

                                                            // Close mobile
                                                            // sidebar only
                                                            onNavigate?.();

                                                        }}
                                                    >

                                                        <ChildIcon
                                                            size={16}
                                                        />

                                                        <span>
                                                            {
                                                                child.label
                                                            }
                                                        </span>

                                                    </NavLink>
                                                );

                                            }
                                        )}

                                    </div>

                                )}

                            </div>
                        );
                    }


                    /*
                     * NORMAL SIDEBAR ITEMS
                     */

                    return (
                        <NavLink
                            key={item.path}
                            to={item.path}
                            className={({ isActive }) =>
                                isActive
                                    ? "nav-item active"
                                    : "nav-item"
                            }
                            onClick={() => {

                                /*
                                 * Any other sidebar item
                                 * closes Society dropdown.
                                 */

                                setSocietyMenuOpen(false);

                                // Close mobile sidebar
                                onNavigate?.();

                            }}
                        >

                            <Icon size={19} />

                            <span>
                                {item.label}
                            </span>

                        </NavLink>
                    );

                })}

            </nav>


            {/* FOOTER */}

            <div className="sidebar-footer">

                <button
                    className="logout-button"
                    onClick={logout}
                >

                    <LogOut size={18} />

                    <span>
                        Logout
                    </span>

                </button>

            </div>

        </aside>
    );
};

export default Sidebar;