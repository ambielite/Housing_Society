
import {
    Bell,
    ChevronDown,
    Menu,
    Moon,
    Sun
} from "lucide-react";

import { useAuth } from "../../app/providers/useAuth";
import { useSociety } from "../../app/store/useSociety";
import { useTheme } from "../../app/providers/useTheme";

const Topbar = ({ onMenuClick }) => {

    const { user } = useAuth();
    const { selectedSociety } = useSociety();
    const { theme, toggleTheme } = useTheme();

    return (
        <header className="topbar">

            {/* Left Side */}
            <div className="topbar-left">

                <button
                    className="mobile-menu-button"
                    onClick={onMenuClick}
                    type="button"
                    aria-label="Open menu"
                >
                    <Menu size={22} />
                </button>

                <div className="current-society">

                    <span className="topbar-label">
                        Current Society
                    </span>

                    <strong>
                        {selectedSociety?.name ||
                            "Select Society"}
                    </strong>

                </div>

            </div>


            {/* Right Side */}
            <div className="topbar-right">

                {/* Theme Toggle */}
                <button
                    type="button"
                    className="theme-toggle"
                    onClick={toggleTheme}
                    title={
                        theme === "light"
                            ? "Switch to Dark Mode"
                            : "Switch to Light Mode"
                    }
                    aria-label={
                        theme === "light"
                            ? "Switch to Dark Mode"
                            : "Switch to Light Mode"
                    }
                >
                    {theme === "light" ? (
                        <Moon size={19} />
                    ) : (
                        <Sun size={19} />
                    )}
                </button>


                {/* Notifications */}
                <button
                    type="button"
                    className="notification-button"
                    title="Notifications"
                >
                    <Bell size={20} />

                    <span className="notification-dot"></span>
                </button>


                {/* User Menu */}
                <div className="user-menu">

                    <div className="avatar">
                        {user?.name
                            ?.charAt(0)
                            ?.toUpperCase() || "A"}
                    </div>

                    <div className="user-info">

                        <strong>
                            {user?.name ||
                                "Administrator"}
                        </strong>

                        <span>
                            {user?.role ||
                                "Admin"}
                        </span>

                    </div>

                    <ChevronDown size={17} />

                </div>

            </div>

        </header>
    );
};

export default Topbar;

